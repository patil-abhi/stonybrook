import tensorflow as tf
import numpy as np
import math

def cross_entropy_loss(inputs, true_w):
    """
    ==========================================================================

    inputs: The embeddings for context words. Dimension is [batch_size, embedding_size].
    true_w: The embeddings for predicting words. Dimension of true_w is [batch_size, embedding_size].

    Write the code that calculate A = log(exp({u_o}^T v_c))

    A =


    And write the code that calculate B = log(\sum{exp({u_w}^T v_c)})


    B =

    ==========================================================================
    """
    A = tf.log(tf.exp(tf.matmul(tf.transpose(true_w),inputs)))
    B = tf.log(tf.reduce_sum(tf.exp(tf.matmul(tf.transpose(true_w),inputs)),1))
    return tf.subtract(B, A)

def nce_loss(inputs, weights, biases, labels, sample, unigram_prob):
    """
    ==========================================================================
    inputs: Embeddings for context words. Dimension is [batch_size, embedding_size].
    weigths: Weights for nce loss. Dimension is [Vocabulary, embeeding_size].
    biases: Biases for nce loss. Dimension is [Vocabulary, 1].
    labels: Word_ids for predicting words. Dimesion is [batch_size, 1].
    samples: Word_ids for negative samples. Dimension is [num_sampled].
    unigram_prob: Unigram probability. Dimesion is [Vocabulary].

    Implement Noise Contrastive Estimation Loss Here

    ==========================================================================
    """
    #import pdb; pdb.set_trace()
    batchSize = labels.shape.as_list()[0]
    embeddingSize = weights.shape.as_list()[1]



    unigram = tf.convert_to_tensor(unigram_prob, dtype=tf.float32)
    w_o=tf.nn.embedding_lookup(unigram,labels)
    w_o=tf.reshape(w_o, [batchSize])

    sampleSize = len(sample)
    w_x = np.ndarray(shape=(sampleSize), dtype=np.float32)
    for i in range(sampleSize):
        w_x[i] = unigram_prob[sample[i]]

    #center word vector
    u_c = tf.nn.embedding_lookup(weights, labels)
    u_c = tf.reshape(u_c, [-1, embeddingSize])
    #context outer words
    u_o = inputs
    #bias
    bias_o=tf.nn.embedding_lookup(biases,labels)
    bias_o =tf.reshape(bias_o, [batchSize])

    u_x=tf.nn.embedding_lookup(weights, sample)
    #bias
    bias_x=tf.nn.embedding_lookup(biases,sample)
    k = sampleSize
    #print("k: "+ str(k) + " embeddingSize: "+ str(embeddingSize)+ " batchSize: "+ str(batchSize))

    #import pdb; pdb.set_trace()

    exp1 = tf.log(tf.sigmoid(tf.diag_part(tf.matmul(u_o,tf.transpose(u_c)))+bias_o - tf.log(k*w_o+ math.pow(10,-8)) )+ math.pow(10,-8))

    exp2 = tf.reduce_sum(tf.log(1-tf.sigmoid(tf.matmul(u_o,tf.transpose(u_x))+bias_x-tf.log(k*w_x+ math.pow(10,-8)))+ math.pow(10,-8)),1)

    return -(exp1+exp2)
