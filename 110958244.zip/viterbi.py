import numpy as np
import sys

def run_viterbi(emission_scores, trans_scores, start_scores, end_scores):
    """Run the Viterbi algorithm.

    N - number of tokens (length of sentence)
    L - number of labels

    As an input, you are given:
    - Emission scores, as an NxL array
    - Transition scores (Yp -> Yc), as an LxL array
    - Start transition scores (S -> Y), as an Lx1 array
    - End transition scores (Y -> E), as an Lx1 array

    You have to return a tuple (s,y), where:
    - s is the score of the best sequence
    - y is the size N array/seq of integers representing the best sequence.
    """
    L = start_scores.shape[0]
    assert end_scores.shape[0] == L
    assert trans_scores.shape[0] == L
    assert trans_scores.shape[1] == L
    assert emission_scores.shape[1] == L
    N = emission_scores.shape[0]


    y = []
    # for i in xrange(N):
    #     # stupid sequence
    #     y.append(i % L)
    # # score set to 0
    #return (0.0, y)

    dpMat = np.zeros(emission_scores.shape)

    #to back track the paths
    backTrackMat = np.zeros(emission_scores.shape, dtype=np.int32)

    #populate the first one
    for i in range(L):
        dpMat[0][i] = emission_scores[0][i] + start_scores[i]
        backTrackMat[0][i] = 0

    #compute the next ones based on the value of previous one and transition scores.
    for i in range(N-1):
        for j in range(L):
            for k in range(L):
                value = emission_scores[i+1][j] + dpMat[i][k] + trans_scores[k][j]
                if value > dpMat[i+1][j]:
                    dpMat[i+1][j] = value
                    backTrackMat[i+1][j] = k

    sumList = []
    for i in range(L):
        sumList.append(dpMat[N-1][i] + end_scores[i])
    score_end = -sys.maxint
    last_end = 0

    for i,sum in enumerate(sumList):
        if sum > score_end:
            score_end = sum
            last_end = i

    #import pdb; pdb.set_trace()
    tags = list()
    tags.append(last_end)

    #backtrack and get the path
    index = last_end
    for i in range(N-1,0,-1):
        tags.append(backTrackMat[i][index])
        index = backTrackMat[i][index]

    #return the path from start
    return (score_end, tags[::-1])
