import os
import pickle
import numpy as np
import tensorflow as tf


model_path = './models/'
#loss_model = 'cross_entropy'
loss_model = 'nce'

model_filepath = os.path.join(model_path, 'word2vec_%s.model'%(loss_model))

dictionary, steps, embeddings = pickle.load(open(model_filepath, 'r'))

#import pdb; pdb.set_trace()
"""
==========================================================================

Write code to evaluate a relation between pairs of words.
You can access your trained model via dictionary and embeddings.
dictionary[word] will give you word_id
and embeddings[word_id] will return the embedding for that word.

word_id = dictionary[word]
v1 = embeddings[word_id]

or simply

v1 = embeddings[dictionary[word_id]]

==========================================================================
"""
def cosine_similarity(embedLeft, embedRight):
     denominator = tf.multiply(tf.linalg.norm(embedLeft), tf.linalg.norm(embedRight))
     numerator = tf.reduce_sum(tf.multiply(embedLeft,embedRight))
     #import pdb; pdb.set_trace()
     diff =tf.div(numerator,denominator)
     return tf.abs(diff)

#printLog = tf.Print(dictionary, [dictionary], message='dictionary: ',first_n=1)
#import pdb; pdb.set_trace()
inputFile = open('word_analogy_test.txt', 'r')
lines = inputFile.readlines()
inputFile.close()

outputFile = open('dev_predictions_nce.txt','w')

for line in lines:
    line = line.strip()
    samples = line.split("||")
    examplePairs = samples[0].split(",")
    choicesPairs = samples[1].split(",")

    diffSum = 0
    for example in examplePairs:
        ex = example.split(":")
        exampleLeft = ex[0].strip("\"")
        exampleRight = ex[1].strip("\"")

        #
        if exampleLeft in dictionary:
            embedLeft=embeddings[dictionary[exampleLeft]]
        else:
            embedLeft= embeddings[dictionary['a']]
            print("not found in dict: "+ exampleLeft)

        if exampleRight in dictionary:
            embedRight = embeddings[dictionary[exampleRight]]
        else:
            embedRight = embeddings[dictionary['a']]
            print("not found in dict: "+ exampleRight)

        diff =(embedRight-embedLeft)

        diffSum += diff
        #print("diff of "+ str(exampleLeft)+","+str(exampleRight)+" : "+ str(diff))
    avgDiff = diffSum/3

    #check difference of choices with this average difference
    choiceDifferences = []
    for i in range(len(choicesPairs)):
        ch = choicesPairs[i].split(":")
        choiceLeft = ch[0].strip("\"")
        choiceRight = ch[1].strip("\"")
        if choiceLeft in dictionary:
            embedChoiceLeft = embeddings[dictionary[choiceLeft]]
        else:
            embedChoiceLeft = embeddings[dictionary['a']]
        if choiceRight in dictionary:
            embedChoiceRight = embeddings[dictionary[choiceRight]]
        else:
            embedChoiceRight = embeddings[dictionary['a']]
        choiceDifferences.append([i,cosine_similarity(embedChoiceRight-embedChoiceLeft,avgDiff)])
        #choiceDifferences.append([i,cosine_similarity(embedChoiceLeft- embedChoiceRight,avgDiff)])
    #print (choiceDifferences)
    #print("avgDiff :" + str(avgDiff))
    minSimilar = None
    maxSimilar = None
    #import pdb; pdb.set_trace()
    for i in range(len(choiceDifferences)):
        cd = choiceDifferences[i]
        if not minSimilar:
            minSimilar = i
        elif cd < choiceDifferences[minSimilar]:
            minSimilar = i
        if not maxSimilar:
            maxSimilar = i
        elif cd > choiceDifferences[maxSimilar]:
            maxSimilar = i
    #print(choiceDifferences)
    outputLine = samples[1].replace(","," ") + " " + choicesPairs[maxSimilar] + " "+ choicesPairs[minSimilar]
    #print(outputLine)
    outputFile.write(outputLine+"\n")
